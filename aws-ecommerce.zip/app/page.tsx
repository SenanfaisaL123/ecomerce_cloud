import App from "../frontend/src/App"

export default function Page() {
  return <App />
}
